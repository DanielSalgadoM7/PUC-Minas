using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuPrincipalManager : MonoBehaviour
{
    //vari�veis
    [SerializeField] private string nomeMapa;
    [SerializeField] private GameObject painelMenuInicial;
    [SerializeField] private GameObject painelOptions;
    [SerializeField] private GameObject painelCreditos;

    public void Jogar()
    {
        SceneManager.LoadScene(nomeMapa);
    }

    public void Menu()
    {
        SceneManager.LoadScene(nomeMapa);
    }

    public void AbrirOptions()
    {
        painelMenuInicial.SetActive(false);
        painelOptions.SetActive(true);
    }

    public void FecharOptions()
    {
        painelOptions.SetActive(false);
        painelMenuInicial.SetActive(true);
    }

    public void AbrirCreditos()
    {
        painelMenuInicial.SetActive(false);
        painelCreditos.SetActive(true);
    }

    public void FecharCreditos()
    {
        painelMenuInicial.SetActive(true);
        painelCreditos.SetActive(false);
    }

    public void Quit()
    {

        Debug.Log("Sair do Jogo");

        //o m�todo s� funciona dps que o jogo ta todo compilado
        Application.Quit();
    }

}
