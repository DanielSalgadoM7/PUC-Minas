using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScriptFase1 : MonoBehaviour
{
    public GameObject bottombar;


    public void ToggleBottomBarVisibility()
    {
        bool isActive = bottombar.activeSelf;
        bottombar.SetActive(!isActive);
    }
}