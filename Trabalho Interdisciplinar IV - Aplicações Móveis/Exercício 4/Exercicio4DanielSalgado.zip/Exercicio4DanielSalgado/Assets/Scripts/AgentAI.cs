using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class AgentAI : MonoBehaviour
{

    public List<Transform> wayPoint;

    NavMeshAgent navMeshAgent;

    public int currentWaypointIndex = 0;

    void Start()
    {
        navMeshAgent = GetComponent<NavMeshAgent>();

    }

    void Update()
    {
        Walking();
    }

    private void Walking()
    {

        if (wayPoint.Count == 0)
        {

            return;
        }

        float distanceToWaypoint = Vector3.Distance(wayPoint[currentWaypointIndex].position, transform.position);

        // checa se o agente t� pr�ximo do waypoint
        if (distanceToWaypoint <= 2)
        {

            currentWaypointIndex = (currentWaypointIndex + 1) % wayPoint.Count;
        }

        // marca o destino pro waypoint atual
        navMeshAgent.SetDestination(wayPoint[currentWaypointIndex].position);
    }

}