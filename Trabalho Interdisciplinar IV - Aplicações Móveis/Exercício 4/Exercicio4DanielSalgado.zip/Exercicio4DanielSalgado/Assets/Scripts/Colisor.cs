using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro; 

public class Colisor : MonoBehaviour
{
    public int pontos = 0;
    public TextMeshProUGUI hudpontos;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Item"))
        {
            pontos += collision.gameObject.GetComponent<Item>().valor;
            hudpontos.text = pontos.ToString(); // Atualiza o texto
            Destroy(collision.gameObject);
        }
    }
}
